<?php
class PEAR2_MultiErrors_Exception extends PEAR2_Exception {}